<section id="conclusion">
  <h1 class="body-header">Concluding Text</h1>
  <p class="body-text">
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos voluptas dicta
    blanditiis doloremque dolorum asperiores fugiat non, obcaecati maiores id,
    voluptatum possimus libero iure laudantium dignissimos corrupti? Iure omnis
    consectetur aperiam ipsam quod eum quas similique atque laboriosam ex
    accusantium quaerat laudantium, est a libero sed cumque odio perspiciatis
    enim, sequi, corrupti alias beatae nulla. Iure est ut dignissimos debitis
    optio quasi vel distinctio officiis doloremque, ad voluptates, omnis nam
    corporis, aut exercitationem ex excepturi tempore et modi unde alias nemo
    accusantium. Tempore odio nulla ex ad ut molestiae unde minima ipsam
    aliquid, omnis, labore commodi aliquam incidunt ratione autem?
  </p>
</section>

<style>
  #conclusion {
    padding: 2rem 1rem;
  }
</style>
