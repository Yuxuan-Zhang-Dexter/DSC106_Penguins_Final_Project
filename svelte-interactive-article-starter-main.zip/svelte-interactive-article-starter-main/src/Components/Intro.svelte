<script>
</script>

<section>
  <p class="body-text">
    Lorem ipsum dolor sit amet <a href="">random link</a> adipisicing elit. Esse
    dolor nobis
    <span class="bold">bold text</span> eius voluptate distinctio odit ut quod illo!
    Nulla consequatur fugiat quia commodi aspernatur necessitatibus est doloremque
    quam vitae dolorem. Vitae natus ipsum animi officiis et quis obcaecati in molestiae
    aperiam, perferendis odio a ipsam nam suscipit laboriosam corporis excepturi
    quisquam? Ratione delectus repellat error maxime quo beatae ullam, quod
  </p>
  <p class="body-text">This is a trr</p>
</section>

<style>
</style>
