// svelte.config.js
const preprocess = require('svelte-preprocess');

module.exports = {
  preprocess: preprocess()
};
